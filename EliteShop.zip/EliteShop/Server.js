import express from "express";
import colors from "colors";
import dotenv from "dotenv";
//config env
dotenv.config()
//rest object
const app = express()
//port
const port = process.env.port || 8086
//rest api
app.get('/', (req, res) => {
  res.send('Welcome to EliteShop')
})
//listen app
app.listen(port, () => {
  console.log(`Server Running on port ${port}`.bgCyan.white)
})